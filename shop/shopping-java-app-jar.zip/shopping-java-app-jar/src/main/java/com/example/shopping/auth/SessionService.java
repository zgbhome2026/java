package com.example.shopping.auth;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class SessionService {
    private final JdbcTemplate jdbc;

    public SessionService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public String create(long userId) {
        String token = UUID.randomUUID().toString();
        jdbc.update(
                "INSERT INTO user_sessions(token,user_id,expires_at) VALUES (?,?,?)",
                token, userId, LocalDateTime.now().plusHours(8)
        );
        return token;
    }

    public long requireUser(String token) {
        if (token == null || token.isBlank()) {
            throw new SecurityException("Missing X-Session-Token");
        }

        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT user_id FROM user_sessions WHERE token = ? AND expires_at > CURRENT_TIMESTAMP",
                token
        );

        if (rows.isEmpty()) {
            throw new SecurityException("Invalid or expired session");
        }

        return ((Number) rows.get(0).get("user_id")).longValue();
    }

    public void delete(String token) {
        if (token != null && !token.isBlank()) {
            jdbc.update("DELETE FROM user_sessions WHERE token = ?", token);
        }
    }
}
