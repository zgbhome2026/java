package com.example.shopping.checkout;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class CheckoutService {
    private final JdbcTemplate jdbc;

    public CheckoutService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Transactional
    public Map<String, Object> checkout(long userId) {
        List<Map<String, Object>> cartRows = jdbc.queryForList(
                "SELECT c.id AS cart_id, p.id AS product_id, p.name, p.price, p.stock, ci.quantity " +
                "FROM carts c " +
                "JOIN cart_items ci ON ci.cart_id = c.id " +
                "JOIN products p ON p.id = ci.product_id " +
                "WHERE c.user_id = ? FOR UPDATE OF p",
                userId
        );

        if (cartRows.isEmpty()) {
            throw new IllegalArgumentException("Cart is empty");
        }

        BigDecimal total = BigDecimal.ZERO;

        for (Map<String, Object> row : cartRows) {
            int stock = ((Number) row.get("stock")).intValue();
            int quantity = ((Number) row.get("quantity")).intValue();

            if (stock < quantity) {
                throw new IllegalArgumentException("Not enough stock for " + row.get("name"));
            }

            BigDecimal price = (BigDecimal) row.get("price");
            total = total.add(price.multiply(BigDecimal.valueOf(quantity)));
        }

        long orderId = jdbc.queryForObject(
                "INSERT INTO orders(user_id,total_amount,status) VALUES (?,?,'PAID') RETURNING id",
                Long.class,
                userId, total
        );

        for (Map<String, Object> row : cartRows) {
            long productId = ((Number) row.get("product_id")).longValue();
            int quantity = ((Number) row.get("quantity")).intValue();
            BigDecimal price = (BigDecimal) row.get("price");
            BigDecimal lineTotal = price.multiply(BigDecimal.valueOf(quantity));

            jdbc.update(
                    "INSERT INTO order_items(order_id, product_id, product_name, unit_price, quantity, line_total) " +
                    "VALUES (?,?,?,?,?,?)",
                    orderId,
                    productId,
                    row.get("name"),
                    price,
                    quantity,
                    lineTotal
            );

            jdbc.update(
                    "UPDATE products SET stock = stock - ? WHERE id = ?",
                    quantity, productId
            );
        }

        long cartId = ((Number) cartRows.get(0).get("cart_id")).longValue();
        jdbc.update("DELETE FROM cart_items WHERE cart_id = ?", cartId);

        Map<String, Object> receipt = new LinkedHashMap<>();
        receipt.put("orderId", orderId);
        receipt.put("status", "PAID");
        receipt.put("total", total);
        return receipt;
    }

    public List<Map<String, Object>> orders(long userId) {
        return jdbc.queryForList(
                "SELECT id, total_amount, status, created_at " +
                "FROM orders WHERE user_id = ? ORDER BY id DESC",
                userId
        );
    }
}
