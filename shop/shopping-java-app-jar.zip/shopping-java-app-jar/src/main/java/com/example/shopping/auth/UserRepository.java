package com.example.shopping.auth;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class UserRepository {
    private final JdbcTemplate jdbc;

    public UserRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public long create(String username, String email, String passwordHash) {
        return jdbc.queryForObject(
                "INSERT INTO users(username,email,password_hash) VALUES (?,?,?) RETURNING id",
                Long.class,
                username, email, passwordHash
        );
    }

    public Optional<Map<String, Object>> findByUsername(String username) {
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT id, username, email, password_hash, role, enabled FROM users WHERE username = ?",
                username
        );
        return rows.stream().findFirst();
    }

    public Optional<Map<String, Object>> findById(long id) {
        List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT id, username, email, role, enabled, created_at FROM users WHERE id = ?",
                id
        );
        return rows.stream().findFirst();
    }
}
