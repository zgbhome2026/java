package com.example.shopping.auth;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class LoginHistoryRepository {
    private final JdbcTemplate jdbc;

    public LoginHistoryRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void save(Long userId, String username, String ipAddress, boolean success) {
        jdbc.update(
                "INSERT INTO login_history(user_id,username,ip_address,success) VALUES (?,?,?,?)",
                userId, username, ipAddress, success
        );
    }
}
