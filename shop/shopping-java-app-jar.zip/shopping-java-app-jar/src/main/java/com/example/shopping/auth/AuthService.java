package com.example.shopping.auth;

import com.example.shopping.auth.dto.LoginRequest;
import com.example.shopping.auth.dto.LoginResponse;
import com.example.shopping.auth.dto.RegisterRequest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class AuthService {
    private final UserRepository users;
    private final LoginHistoryRepository history;
    private final SessionService sessions;
    private final BCryptPasswordEncoder encoder;

    public AuthService(UserRepository users,
                       LoginHistoryRepository history,
                       SessionService sessions,
                       BCryptPasswordEncoder encoder) {
        this.users = users;
        this.history = history;
        this.sessions = sessions;
        this.encoder = encoder;
    }

    public long register(RegisterRequest request) {
        if (request.username == null || request.username.isBlank()) {
            throw new IllegalArgumentException("Username is required");
        }
        if (request.password == null || request.password.length() < 8) {
            throw new IllegalArgumentException("Password must be at least 8 characters");
        }

        return users.create(
                request.username.trim(),
                request.email,
                encoder.encode(request.password)
        );
    }

    public LoginResponse login(LoginRequest request, String ipAddress) {
        if (request.username == null || request.password == null) {
            throw new IllegalArgumentException("Username and password are required");
        }

        var userOpt = users.findByUsername(request.username);

        if (userOpt.isEmpty()) {
            history.save(null, request.username, ipAddress, false);
            throw new SecurityException("Invalid username or password");
        }

        Map<String, Object> user = userOpt.get();
        long id = ((Number) user.get("id")).longValue();
        boolean enabled = Boolean.TRUE.equals(user.get("enabled"));
        String hash = (String) user.get("password_hash");

        if (!enabled || !encoder.matches(request.password, hash)) {
            history.save(id, request.username, ipAddress, false);
            throw new SecurityException("Invalid username or password");
        }

        history.save(id, request.username, ipAddress, true);
        String token = sessions.create(id);

        return new LoginResponse(token, id, (String) user.get("username"));
    }
}
