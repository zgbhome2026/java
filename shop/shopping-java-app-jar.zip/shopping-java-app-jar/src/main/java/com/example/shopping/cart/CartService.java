package com.example.shopping.cart;

import com.example.shopping.cart.dto.CartItemRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class CartService {
    private final JdbcTemplate jdbc;

    public CartService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    private long cartId(long userId) {
        List<Long> ids = jdbc.query(
                "SELECT id FROM carts WHERE user_id = ?",
                (rs, rowNum) -> rs.getLong("id"),
                userId
        );

        if (!ids.isEmpty()) {
            return ids.get(0);
        }

        return jdbc.queryForObject(
                "INSERT INTO carts(user_id) VALUES (?) RETURNING id",
                Long.class,
                userId
        );
    }

    @Transactional
    public void add(long userId, CartItemRequest req) {
        if (req.quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero");
        }

        Integer count = jdbc.queryForObject(
                "SELECT COUNT(*) FROM products WHERE id = ? AND active = TRUE",
                Integer.class,
                req.productId
        );
        if (count == null || count == 0) {
            throw new IllegalArgumentException("Product not found");
        }

        long cartId = cartId(userId);

        jdbc.update(
                "INSERT INTO cart_items(cart_id, product_id, quantity) VALUES (?,?,?) " +
                "ON CONFLICT (cart_id, product_id) " +
                "DO UPDATE SET quantity = cart_items.quantity + EXCLUDED.quantity",
                cartId, req.productId, req.quantity
        );

        jdbc.update(
                "UPDATE carts SET updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                cartId
        );
    }

    @Transactional
    public void update(long userId, long productId, int quantity) {
        long cartId = cartId(userId);

        if (quantity <= 0) {
            jdbc.update(
                    "DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?",
                    cartId, productId
            );
        } else {
            jdbc.update(
                    "UPDATE cart_items SET quantity = ? WHERE cart_id = ? AND product_id = ?",
                    quantity, cartId, productId
            );
        }

        jdbc.update(
                "UPDATE carts SET updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                cartId
        );
    }

    public Map<String, Object> get(long userId) {
        long cartId = cartId(userId);

        List<Map<String, Object>> items = jdbc.queryForList(
                "SELECT p.id AS product_id, p.sku, p.name, p.price, ci.quantity, " +
                "(p.price * ci.quantity) AS line_total " +
                "FROM cart_items ci " +
                "JOIN products p ON p.id = ci.product_id " +
                "WHERE ci.cart_id = ? ORDER BY p.id",
                cartId
        );

        BigDecimal total = items.stream()
                .map(row -> (BigDecimal) row.get("line_total"))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("cartId", cartId);
        result.put("items", items);
        result.put("total", total);
        return result;
    }

    public void clear(long userId) {
        long cartId = cartId(userId);
        jdbc.update("DELETE FROM cart_items WHERE cart_id = ?", cartId);
    }
}
