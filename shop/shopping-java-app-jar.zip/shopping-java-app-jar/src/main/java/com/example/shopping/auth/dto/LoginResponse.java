package com.example.shopping.auth.dto;

public class LoginResponse {
    public final String token;
    public final long userId;
    public final String username;

    public LoginResponse(String token, long userId, String username) {
        this.token = token;
        this.userId = userId;
        this.username = username;
    }
}
