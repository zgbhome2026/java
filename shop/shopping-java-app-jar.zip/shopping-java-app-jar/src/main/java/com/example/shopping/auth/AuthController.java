package com.example.shopping.auth;

import com.example.shopping.auth.dto.LoginRequest;
import com.example.shopping.auth.dto.LoginResponse;
import com.example.shopping.auth.dto.RegisterRequest;
import javax.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    private final SessionService sessions;
    private final UserRepository users;

    public AuthController(AuthService auth, SessionService sessions, UserRepository users) {
        this.auth = auth;
        this.sessions = sessions;
        this.users = users;
    }

    @PostMapping("/register")
    public Map<String, Object> register(@RequestBody RegisterRequest request) {
        long id = auth.register(request);
        return Map.of("userId", id, "username", request.username);
    }

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest request,
                               HttpServletRequest httpRequest) {
        return auth.login(request, clientIp(httpRequest));
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(
            @RequestHeader(value = "X-Session-Token", required = false) String token) {
        sessions.delete(token);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/me")
    public Map<String, Object> me(@RequestHeader("X-Session-Token") String token) {
        long userId = sessions.requireUser(token);
        return users.findById(userId)
                .orElseThrow(() -> new SecurityException("User not found"));
    }

    private String clientIp(HttpServletRequest request) {
        String forwarded = request.getHeader("X-Forwarded-For");
        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
