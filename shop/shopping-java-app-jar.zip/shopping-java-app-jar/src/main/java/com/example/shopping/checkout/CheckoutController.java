package com.example.shopping.checkout;

import com.example.shopping.auth.SessionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class CheckoutController {
    private final SessionService sessions;
    private final CheckoutService checkout;

    public CheckoutController(SessionService sessions, CheckoutService checkout) {
        this.sessions = sessions;
        this.checkout = checkout;
    }

    @PostMapping("/checkout")
    public Map<String, Object> checkout(
            @RequestHeader("X-Session-Token") String token) {
        return checkout.checkout(sessions.requireUser(token));
    }

    @GetMapping("/orders")
    public List<Map<String, Object>> orders(
            @RequestHeader("X-Session-Token") String token) {
        return checkout.orders(sessions.requireUser(token));
    }
}
