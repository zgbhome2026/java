package com.example.shopping.cart.dto;

public class CartItemRequest {
    public long productId;
    public int quantity;
}
