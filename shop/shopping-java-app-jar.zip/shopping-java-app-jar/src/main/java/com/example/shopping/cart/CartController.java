package com.example.shopping.cart;

import com.example.shopping.auth.SessionService;
import com.example.shopping.cart.dto.CartItemRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartController {
    private final SessionService sessions;
    private final CartService cart;

    public CartController(SessionService sessions, CartService cart) {
        this.sessions = sessions;
        this.cart = cart;
    }

    @GetMapping
    public Map<String, Object> get(@RequestHeader("X-Session-Token") String token) {
        return cart.get(sessions.requireUser(token));
    }

    @PostMapping("/items")
    public ResponseEntity<Void> add(
            @RequestHeader("X-Session-Token") String token,
            @RequestBody CartItemRequest request) {
        cart.add(sessions.requireUser(token), request);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/items/{productId}")
    public ResponseEntity<Void> update(
            @RequestHeader("X-Session-Token") String token,
            @PathVariable long productId,
            @RequestParam int quantity) {
        cart.update(sessions.requireUser(token), productId, quantity);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping
    public ResponseEntity<Void> clear(@RequestHeader("X-Session-Token") String token) {
        cart.clear(sessions.requireUser(token));
        return ResponseEntity.noContent().build();
    }
}
