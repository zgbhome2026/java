package com.example.shopping.auth.dto;

public class LoginRequest {
    public String username;
    public String password;
}
